const TOKEN_KEY = 'workflow.token';

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (token) => localStorage.setItem(TOKEN_KEY, token);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

/**
 * Thin fetch wrapper: attaches the Bearer token, parses JSON and turns any
 * non-2xx response into a thrown Error carrying the server's message.
 */
const request = async (path, { method = 'GET', body, auth = true } = {}) => {
  const headers = { 'Content-Type': 'application/json' };

  if (auth) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(`/api${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  let data = null;
  const text = await response.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { message: text };
    }
  }

  if (!response.ok) {
    const error = new Error((data && data.message) || `Request failed (${response.status})`);
    error.status = response.status;
    throw error;
  }

  return data;
};

export const api = {
  login: (email, password) =>
    request('/auth/login', { method: 'POST', body: { email, password }, auth: false }),
  register: (name, email, password) =>
    request('/auth/register', { method: 'POST', body: { name, email, password }, auth: false }),
  me: () => request('/auth/me'),

  getTeams: () => request('/teams'),
  getTeam: (key) => request(`/teams/${key}`),
  createTeam: (payload) => request('/teams', { method: 'POST', body: payload }),

  getUsers: () => request('/users'),

  getAllIssues: (query = '') => request(`/issues${query}`),
  getIssuesByTeam: (teamId) => request(`/issues/team/${teamId}`),
  getIssue: (identifier) => request(`/issues/${identifier}`),
  createIssue: (payload) => request('/issues', { method: 'POST', body: payload }),
  updateIssue: (identifier, payload) =>
    request(`/issues/${identifier}`, { method: 'PATCH', body: payload }),
  deleteIssue: (identifier) => request(`/issues/${identifier}`, { method: 'DELETE' }),

  getComments: (identifier) => request(`/comments/${identifier}`),
  createComment: (identifier, body) =>
    request(`/comments/${identifier}`, { method: 'POST', body: { body } }),

  getActivities: (identifier) => request(`/activities/${identifier}`),
};

export default api;
