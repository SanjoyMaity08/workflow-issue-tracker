import express from 'express';
import { getActivitiesForIssue } from '../controllers/activityController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

router.use(protect);

router.get('/:identifier', getActivitiesForIssue);

export default router;
