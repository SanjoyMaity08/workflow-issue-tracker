import jwt from 'jsonwebtoken';

/**
 * Sign a JWT for a user id. Used by login and register.
 */
const generateToken = (userId) => {
  const secret = process.env.JWT_SECRET || 'workflow_super_secret_change_me';
  const expiresIn = process.env.JWT_EXPIRES_IN || '7d';

  return jwt.sign({ id: userId }, secret, { expiresIn });
};

export default generateToken;
